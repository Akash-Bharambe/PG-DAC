$(document).ready(function () {
  let interval;
  let i = 0;
    $('#start').click(function () {
      var input = $('#datetime').val();
      
      var countDownDate = new Date(input).getTime();
      
      clearInterval(interval);

      interval = setInterval(function () {
        console.log("counting"+(i++));
        
        var now = new Date().getTime();
  
        var remainingTime = countDownDate - now;
  
        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
        var hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);
  
        // Display the result in the element with id="timer"
        $('#days').text(days);
        $('#hours').text(hours);
        $('#minutes').text(minutes);
        $('#seconds').text(seconds);
  
        // If the count down is over, write some text
        if (remainingTime < 0) {
          clearInterval(window.countdownInterval);
          $('#timer').html("EXPIRED");
        }
      }, 1000);
    });
  });