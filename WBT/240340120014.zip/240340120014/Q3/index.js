const express = require('express');
const fs = require('fs');

const app = express();
const PORT = 3000;

let books = [];

(function loadBooks () {
    fs.readFile("./books.json", 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading books:', err);
            return;
        }
        books = JSON.parse(data);
    });
})()

app.use(express.json());

app.get('/', (_, res) => {
    res.json(books);
});

app.get('/:id', (req, res) => {
    const id = Number.parseInt(req.params.id);
    const book = books.find(b => b.id === id);
    if (book) {
        res.json(book);
    } else {
        res.status(404).send('Book not found');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
