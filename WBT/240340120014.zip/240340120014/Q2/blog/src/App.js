import React, { useState } from 'react';
import Form from './Components/Form';
import List from './Components/List';
import "./App.css"

const App = () => {
  const [blogs, setBlogs] = useState([]);
  const [id, setid] = useState(1);

  const addBlog = (blog) => {
    const newBlog = { id: id, ...blog };
    setid(id+1);
    setBlogs([newBlog, ...blogs]);
  };

  const deleteBlog = (id) => {
    setBlogs(blogs.filter((blog) => blog.id !== id));
  };

  return (
    <div id='container1'>
      <h1>Blog Application</h1>
      <Form addBlog={addBlog} />
      <List blogs={blogs} deleteBlog={deleteBlog} />
    </div>
  );
};

export default App;
