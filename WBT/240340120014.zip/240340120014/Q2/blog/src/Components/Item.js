import React from 'react';
import '../App.css';

const Item = ({ blog, deleteBlog }) => {
  return (
    <div className="blog-item">
      <h2>{blog.name}</h2>
      <p>{blog.date}</p>
      <button onClick={() => deleteBlog(blog.id)}>Delete</button>
    </div>
  );
};

export default Item;
