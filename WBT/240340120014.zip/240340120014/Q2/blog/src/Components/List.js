import React from 'react';
import Item from './Item';
import '../App.css';

const List = ({ blogs, deleteBlog }) => {
  return (
    <div id='list-container'>
      {blogs.map((blog) => (
        <Item key={blog.id} blog={blog} deleteBlog={deleteBlog} />
      ))}
    </div>
  );
};

export default List;
