﻿using _240340120014.Exceptions;
using System.ComponentModel.DataAnnotations;

namespace _240340120014.Models
{
    public class Student
    {
        public int StudentNo { get; set; }

        private string? _name;
        [StringLength(50,MinimumLength = 3,ErrorMessage = "Student Name has to be provided")]
        public string? Name
        {
            get => _name;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length >= 3)
                {
                    _name = value;
                }
                else
                {
                    throw new InvalidStudentNameException("Student Name has to be provided");
                }
            }
        }

        private string? _section;
        [StringLength(1,MinimumLength =1, ErrorMessage = "Section should be only 1 character")]
        public string? Section
        {
            get=> _section;
            set
            {
                if (!string.IsNullOrWhiteSpace(value) && value.Length == 1)
                {
                    _section = value;
                }
                else
                {
                    throw new InvalidStudentSectionException("Section should be only 1 character");
                }
            }
        }

        private string? _branch;
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Branch must be provided")]
        public string? Branch
        {
            get => _branch;
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    _branch = value;
                }
                else
                {
                    throw new InvalidStudentBranchException("Branch must be provided");
                }
            }
        }



        private string? _email;
        [EmailAddress(ErrorMessage = "Incorrect Email")]
        [RegularExpression(@"^[^\s@]+@[^\s@]+\.[^\s@]+$")]
        public string? EmailId
        {
            get => _email;
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    _email = value;
                }
                else
                {
                    throw new InvalidStudentEmailIdException("Incorrect Email");
                }
            }
        }
        public Student()
        {
            
        }

        public Student(int id, string? name, string? section, string? branch, string? email)
        {
            StudentNo = id;
            Name = name;
            Section = section;
            Branch = branch;
            EmailId = email;
        }

    }
}
