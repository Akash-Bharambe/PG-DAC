﻿using _240340120014.Models;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    public class DataBaseUtils
    {
        public static async Task<SqlConnection> GetConnection()
        {
            SqlConnection sqlConnection = new()
            {
                ConnectionString = @"Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = School; Integrated Security = True;MultipleActiveResultSets=true"
            };
            sqlConnection.Open();
            return await Task.Run(() => sqlConnection);
        }

        public static async Task<List<Student>> GetAllStudents()
        {
            SqlConnection sqlConnection = await GetConnection();
            SqlCommand sqlCommand = new()
            {
                Connection = sqlConnection,
                CommandType = CommandType.Text,
                CommandText = "select * from Students"
            };

            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader(CommandBehavior.CloseConnection);
            List<Student> list = [];
            while (sqlDataReader.Read())
            {
                Student student = new(sqlDataReader.GetInt32("StudentNo"), sqlDataReader.GetString("Name"), sqlDataReader.GetString("Section"), sqlDataReader.GetString("Branch"), sqlDataReader.GetString("EmailId"));
                list.Add(student);
            }
            sqlDataReader.Close();
            return list;
        }

        public static async Task<Student?> GetSingleStudent(int id)
        {
            SqlConnection connection = await GetConnection();
            Student? student = null;
            SqlCommand sqlCommand = new()
            {
                Connection = connection,
                CommandType = CommandType.Text,
                CommandText = "select * from Students where StudentNo = @StudentNo"
            };

            sqlCommand.Parameters.AddWithValue("@StudentNo", id);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader(CommandBehavior.CloseConnection);
            if (sqlDataReader.Read())
            {
                student = new(sqlDataReader.GetInt32("StudentNo"), sqlDataReader.GetString("Name"), sqlDataReader.GetString("Section"), sqlDataReader.GetString("Branch"), sqlDataReader.GetString("EmailId"));
            }
            sqlDataReader.Close();
            return student;
        }

        public static async Task Insert(Student student)
        {
            SqlConnection sqlConnection = await GetConnection();
            SqlCommand sqlCommand = new()
            {
                Connection = sqlConnection,
                CommandType = CommandType.Text,
                CommandText = "insert into Students (Name, Section, Branch, EmailId) values(@Name, @Section, @Branch, @EmailId)"
            };
      
            sqlCommand.Parameters.AddWithValue("@Name", student.Name);
            sqlCommand.Parameters.AddWithValue("@Section", student.Section);
            sqlCommand.Parameters.AddWithValue("@Branch", student.Branch);
            sqlCommand.Parameters.AddWithValue("@EmailId", student.EmailId);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }

        public static async Task Update(int id, Student student)
        {
            SqlConnection connection = await GetConnection();
            SqlCommand sqlCommand = new()
            {
                Connection = connection,
                CommandType = CommandType.Text,
                CommandText = "update Students set  Name = @Name, Section = @Section, Branch = @Branch, EmailId = @EmailId where StudentNo = @StudentNo"
            };
            sqlCommand.Parameters.AddWithValue("@StudentNo", id);
            sqlCommand.Parameters.AddWithValue("@Name", student.Name);
            sqlCommand.Parameters.AddWithValue("@Section", student.Section);
            sqlCommand.Parameters.AddWithValue("@Branch", student.Branch);
            sqlCommand.Parameters.AddWithValue("@EmailId", student.EmailId);
            sqlCommand.ExecuteNonQuery();
            connection.Close();
        }

        public static async Task Delete(int id)
        {
            SqlConnection sqlConnection = await GetConnection();
            SqlCommand sqlCommand = new()
            {
                Connection = sqlConnection,
                CommandType = CommandType.Text,
                CommandText = "delete from Students where StudentNo = @StudentNo"
            };
            sqlCommand.Parameters.AddWithValue("@StudentNo", id);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
        }
    }
}
