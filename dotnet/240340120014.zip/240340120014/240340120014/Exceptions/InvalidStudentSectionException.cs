﻿namespace _240340120014
{
    public class InvalidStudentSectionException : ApplicationException
    {
        // Default constructor
        public InvalidStudentSectionException() { }

        // Constructor that accepts a message
        public InvalidStudentSectionException(string message) : base(message) { }
    }
}
