﻿namespace _240340120014.Exceptions
{
    public class InvalidStudentNameException : ApplicationException
    {
        // Default constructor
        public InvalidStudentNameException() { }

        // Constructor that accepts a message
        public InvalidStudentNameException(string message) : base(message) { }
    }
}
