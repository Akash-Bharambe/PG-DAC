﻿namespace _240340120014
{
    public class InvalidStudentBranchException : ApplicationException
    {
        // Default constructor
        public InvalidStudentBranchException() { }

        // Constructor that accepts a message
        public InvalidStudentBranchException(string message) : base(message) { }
    }
}
