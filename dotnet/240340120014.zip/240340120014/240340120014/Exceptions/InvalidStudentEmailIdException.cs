﻿namespace _240340120014
{
    public class InvalidStudentEmailIdException : ApplicationException
    {
        // Default constructor
        public InvalidStudentEmailIdException() { }

        // Constructor that accepts a message
        public InvalidStudentEmailIdException(string message) : base(message) { }
    }
}
