﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DataAccess;
using _240340120014.Models;
namespace _240340120014.Controllers
{
    public class StudentsController : Controller
    {
        // GET: StudentsController
        public async Task<ActionResult> Index()
        {
            List<Student> students = await DataBaseUtils.GetAllStudents();
            return View(students);
        }

        // GET: StudentsController/Details/5
        public async Task<ActionResult> Details(int id)
        {
            Student? student = await DataBaseUtils.GetSingleStudent(id);
            return View(student);
        }

        // GET: StudentsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: StudentsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create(Student student, IFormCollection collection)
        {
            try
            {
                await DataBaseUtils.Insert(student);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentsController/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            Student? student = await DataBaseUtils.GetSingleStudent(id);
            return View(student);
        }

        // POST: StudentsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id,Student student, IFormCollection collection)
        {
            try
            {
                await DataBaseUtils.Update(id, student);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentsController/Delete/5
        public  async Task<ActionResult> Delete(int id)
        {
            Student? student = await DataBaseUtils.GetSingleStudent(id);
            return View(student);
        }

        // POST: StudentsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id, IFormCollection collection)
        {
            try
            {
                await DataBaseUtils.Delete(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
