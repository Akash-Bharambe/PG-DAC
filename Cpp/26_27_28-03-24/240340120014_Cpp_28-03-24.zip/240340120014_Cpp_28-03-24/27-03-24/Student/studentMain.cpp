#include "studentHead.h"
#include <iostream>
using namespace std;

int main()
{
    Student s1;
    s1.accept();
    s1.display();
    return 0;
}