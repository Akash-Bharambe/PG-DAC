#ifndef UTILS_H
#define UTILS_H
#include"empHead.h"
void sortSalary(Employee [], int size);
#endif