#define SIZE 3
void acceptMatrix(int [][SIZE]);
void matrixMultiply(int [][SIZE], int [][SIZE], int [][SIZE]);
void displayMatrix(int [][SIZE]);