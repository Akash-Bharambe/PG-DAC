package app.Hospital;

import org.hibernate.SessionFactory;

import app.Hospital.dao.AppointmentDAOImple;
import app.Hospital.dao.AppointmentDAOImplem;

import static app.Hospital.utils.HibernateUtils.getFactory;

import java.time.LocalDateTime;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        try(SessionFactory sessionFactory = getFactory()
        		
        		
        		) {
			
        	AppointmentDAOImple dao = new AppointmentDAOImplem();
        	System.out.println(dao.addAppointment(1l, 1l, LocalDateTime.now()));
        	
		} catch (Exception e) {
			// TODO: handle exception
		}
    }
}
