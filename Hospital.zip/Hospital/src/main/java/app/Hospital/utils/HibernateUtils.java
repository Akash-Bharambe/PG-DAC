package app.Hospital.utils;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtils {
	private static SessionFactory factory;
	static {
		System.out.println("in init block");
		factory=new Configuration() //empty config
				.configure() //populated config object with props
				.buildSessionFactory();				
	}
	public static SessionFactory getFactory() {
		return factory;
	}
}
