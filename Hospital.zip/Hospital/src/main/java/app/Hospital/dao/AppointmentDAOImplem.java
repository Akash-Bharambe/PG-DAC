package app.Hospital.dao;

import java.time.LocalDateTime;

import org.hibernate.Session;
import org.hibernate.Transaction;

import app.Hospital.entities.Appointment;
import app.Hospital.entities.Doctor;
import app.Hospital.entities.Patient;

import static app.Hospital.utils.HibernateUtils.getFactory;
public class AppointmentDAOImplem implements AppointmentDAOImple {

	@Override
	public String addAppointment(Long patientId, Long doctor_id, LocalDateTime dateTime) {
		
		String msg = "Appointment booking failed";
		String jpql = "select p from Patinet p ";
		
		Session session = getFactory().getCurrentSession();
		
		Transaction tx = session.beginTransaction();
		
		try {
			
			
			Patient patient = session.get(Patient.class, patientId);
			Doctor doctor = session.get(Doctor.class, doctor_id);
			
			Appointment appointment = new Appointment();
			appointment.setDoctor(doctor);
			appointment.setPatient(patient);
			appointment.setAppointmentDateTime(dateTime);
			
			
			session.persist(appointment);
			msg = "Appointment Added Successfully";
			tx.commit();
		} catch (Exception e) {
			if(tx != null) {
				tx.rollback();
			}
			throw e;
		}
		
		return msg;
		
	}

}
