package app.Hospital.dao;

import java.time.LocalDateTime;

public interface AppointmentDAOImple {

	String addAppointment(Long patientId, Long doctor_id, LocalDateTime dateTime);
}
