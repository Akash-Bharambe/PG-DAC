
public class FibonaciiSeries {

	public static int fibonacii(int num) {
		if(num == 0 || num == 1) {
			return num;
		}
		return fibonacii(num-1)+fibonacii(num-2);
	}

	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.print(fibonacii(i)+" ");
		}
	}
}
