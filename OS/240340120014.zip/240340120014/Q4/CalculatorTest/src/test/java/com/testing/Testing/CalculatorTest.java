package com.testing.Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class CalculatorTest {
    private static WebDriver driver;
public static void main(String[] args) {
	

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\dac\\Downloads\\chromedriver.exe");
        driver = new ChromeDriver();

        driver.get("http://testpages.eviltester.com/styled/calculator");
        WebElement addButton = driver.findElement(By.id("calculate"));
        WebElement result = driver.findElement(By.id("answer"));
        WebElement num1 = driver.findElement(By.id("number1"));
        WebElement num2 = driver.findElement(By.id("number2"));
        
        try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        num1.sendKeys("15");
        num2.sendKeys("5");
        addButton.click();

        String resultText = result.getText();
        Assert.assertEquals(resultText, "20", "The result should be 20");
    }

    
}

