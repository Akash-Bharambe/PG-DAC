package com.ticket.entities;

// Enum to represent Ticket Status
public enum Status {
	OPEN, IN_PROGRESS, RESOLVED;
}
