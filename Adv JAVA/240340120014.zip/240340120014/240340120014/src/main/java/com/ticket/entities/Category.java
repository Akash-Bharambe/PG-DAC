package com.ticket.entities;

// Category enum for Ticket Categories
public enum Category {
	SIM, CALLING, BROADBAND;
}

